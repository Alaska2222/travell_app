import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
  TextInput,
  Keyboard,
  TouchableWithoutFeedback,
} from 'react-native';
import ButtonDark from '../components/ButtonDark';

export default function Form({ navigation }) {
  const [experience, setExperience] = useState('');
  const [distance, setDistance] = useState('');
  const [peaks, setPeaks] = useState('');
  const [history, setHistory] = useState([]);

   const SERVER_HOST = 'http://192.168.6.5:8001';

  const handleGenerateRoute = async () => {
    console.log('🔍 handleGenerateRoute triggered');
    if (!experience) {
      Alert.alert('Validation Error', 'Please select your experience level.');
      console.log('⚠️ No experience selected');
      return;
    }

    const routeData = {
      experience_level: experience,
      distance_limit: distance ? parseInt(distance, 10) : undefined,
      peak_limit: peaks ? parseInt(peaks, 10) : undefined,
    };
    console.log('📤 Payload:', routeData);

    setHistory(prev => [...prev, routeData]);

    try {
      console.log('🌐 Pinging root...');
      const ping = await fetch(`${SERVER_HOST}/`);
      console.log('🌐 Root ping status:', ping.status);
      const pingText = await ping.text();
      console.log('🌐 Root ping body:', pingText);

      console.log('🌐 Fetching from server...');
      const res = await fetch(`${SERVER_HOST}/generate-route`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(routeData),
      });
      console.log('⬅️ HTTP status:', res.status);

      const data = await res.json();
      console.log('📥 Response JSON:', data);

      if (data.status === 'ok') {
        console.log('✅ Route generated, navigating to User');
        navigation.navigate('User', { routeData: data.route });
      } else {
        console.log('❌ No route found');
        Alert.alert('No route found', 'Try different parameters.');
      }
    } catch (error) {
      console.error('🚨 Fetch error:', error);
      Alert.alert('Network Error', 'Could not reach route server.');
    }
  };

  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <View style={styles.container}>
        <Text style={styles.label}>Experience *</Text>
        <View style={styles.dropdownContainer}>
          {['Beginner', 'Amateur', 'Experienced'].map(level => (
            <TouchableOpacity
              key={level}
              onPress={() => {
                console.log('🎚 Experience set to:', level);
                setExperience(level);
              }}
              style={[
                styles.dropdownOption,
                experience === level && styles.dropdownSelected,
              ]}
            >
              <Text>{level}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.inptContainer}>
          <TextInput
            placeholder="Distance"
            keyboardType="numeric"
            value={distance}
            onChangeText={text => {
              console.log(' Distance input:', text);
              setDistance(text);
            }}
            style={styles.input}
          />
        </View>

        <View style={styles.inptContainer}>
          <TextInput
            placeholder="Number of Peaks"
            keyboardType="numeric"
            value={peaks}
            onChangeText={text => {
              console.log('Peaks input:', text);
              setPeaks(text);
            }}
            style={styles.input}
          />
        </View>

        <ButtonDark text="Generate Route" width='90%' onPress={handleGenerateRoute} />
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#E3E7E8',
  },
  anotherRegister: {
    color: '#6A707C',
    fontFamily: 'Urbanist_600SemiBold',
    fontSize: 14,
  },
  lowerContainer: {
    marginTop: 20,
    alignItems: 'center',
    width: '80%',
    justifyContent: 'center',
  },
  inptContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '90%',
    height: 52,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#DADADA',
    borderRadius: 8,
    backgroundColor: 'white',
  },
  input: {
    flex: 1,
    height: '100%',
    paddingHorizontal: 10,
  },
  inputField: {
    marginBottom: 30,
  },
  label: {
    alignSelf: 'flex-start',
    marginLeft: '5%',
    fontSize: 16,
    fontFamily: 'Urbanist_600SemiBold',
    marginBottom: 8,
  },
  dropdownContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '90%',
    marginBottom: 30,
  },
  dropdownOption: {
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: '#DADADA',
    borderRadius: 6,
    backgroundColor: 'white',
    width: '35%',
    alignItems: 'center',
  },
  dropdownSelected: {
    backgroundColor: '#cdeed6',
    borderColor: '#4CAF50',
  },
});
