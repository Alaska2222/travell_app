// classificationTree.jsx
// Enhanced risk classification with structured logic and clear recommendations in English

export const classifyRisk = (metrics) => {
  const recommendations = [];

  // === Weather Risk ===
  const weatherFactors = [];
  const wind = metrics["Max Wind Speed"] || 0;
  const windScore = wind > 15 ? 100 : wind > 10 ? 70 : wind > 5 ? 40 : 10;
  weatherFactors.push(windScore);
  if (windScore >= 70) recommendations.push(`⚡️ Strong wind (${wind} m/s)`);

  const rain = metrics["Max Rain (3h)"] || 0;
  const rainScore = rain > 10 ? 100 : rain > 5 ? 60 : rain > 2 ? 30 : 0;
  weatherFactors.push(rainScore);
  if (rainScore >= 60) recommendations.push(`🌧️ Heavy rain (${rain} mm/3h)`);

  const temp = metrics["Min Temperature"] || 0;
  const tempScore = temp < -10 ? 100 : temp < 0 ? 70 : temp < 10 ? 40 : 10;
  weatherFactors.push(tempScore);
  if (tempScore >= 70) recommendations.push(`❄️ Very low temperature (${temp}°C)`);

  const humidity = metrics["Max Humidity"] || 0;
  const humidityScore = humidity > 95 ? 100 : humidity > 85 ? 70 : 40;
  weatherFactors.push(humidityScore);
  if (humidityScore >= 70) recommendations.push(`💧 High humidity (${humidity}%) — fog risk`);

  const weatherRisk = weatherFactors.reduce((sum, v) => sum + v, 0) / weatherFactors.length;

  // === Terrain Risk ===
  const terrainFactors = [];
  const gain = metrics["Total Elevation Gain"] || 0;
  const gainScore = gain > 1200 ? 100 : gain > 800 ? 70 : gain > 400 ? 40 : 10;
  terrainFactors.push(gainScore);
  if (gainScore >= 70) recommendations.push(`⛰️ Significant elevation gain (${gain} m)`);

  const slope = metrics["Max Slope Angle"] || 0;
  const slopeScore = slope > 35 ? 100 : slope > 25 ? 70 : slope > 15 ? 40 : 10;
  terrainFactors.push(slopeScore);
  if (slopeScore >= 70) recommendations.push(`🪨 Steep slopes (${slope.toFixed(1)}°)`);

  const dist = (metrics["Total Route Length (m)"] || 0) / 1000;
  const distScore = dist > 20 ? 100 : dist > 15 ? 70 : dist > 10 ? 40 : 10;
  terrainFactors.push(distScore);
  if (distScore >= 70) recommendations.push(`📏 Long distance (${dist.toFixed(1)} km)`);

  const terrainRisk = terrainFactors.reduce((sum, v) => sum + v, 0) / terrainFactors.length;

  // === POI & Coverage Risk ===
  const waterCount = Object.values(metrics["POI counts for type Water"]?.["5km"] || {}).reduce((a, b) => a + b, 0);
  const waterScore = waterCount < 2 ? 100 : waterCount < 5 ? 60 : 10;
  if (waterScore >= 60) recommendations.push(`🚰 Limited water sources (${waterCount} within 5km)`);

  const emergencyCount = Object.values(metrics["POI counts for type Emergency POI"]?.["10km"] || {}).reduce((a, b) => a + b, 0);
  const emergencyScore = emergencyCount < 1 ? 100 : emergencyCount < 3 ? 60 : 10;
  if (emergencyScore >= 60) recommendations.push(`🆘 Few emergency points (${emergencyCount}/10km)`);

  const coverage = metrics["% of route covered (≤3 km)"] || 0;
  const coverageScore = coverage < 30 ? 100 : coverage < 60 ? 70 : coverage < 90 ? 40 : 10;
  if (coverageScore >= 0) recommendations.push(`📶 Cellular coverage (${coverage}% of route)`);

  const poiCoverageRisk = (waterScore + emergencyScore + coverageScore) / 3;

  // === Composite Risk ===
  const compositeRisk = (weatherRisk * 0.4) + (terrainRisk * 0.4) + (poiCoverageRisk * 0.2);

  const classifyLevel = (score) => {
    if (score < 25) return 'Very Low';
    if (score < 50) return 'Low';
    if (score < 75) return 'Medium';
    if (score < 90) return 'High';
    return 'Very High';
  };

  return {
    weatherRisk: { value: parseFloat(weatherRisk.toFixed(1)), level: classifyLevel(weatherRisk) },
    terrainRisk: { value: parseFloat(terrainRisk.toFixed(1)), level: classifyLevel(terrainRisk) },
    poiRisk: { value: parseFloat(poiCoverageRisk.toFixed(1)), level: classifyLevel(poiCoverageRisk) },
    compositeRisk: { value: parseFloat(compositeRisk.toFixed(1)), level: classifyLevel(compositeRisk) },
    recommendations,
    // Aggregated risk values for diagram rendering
    riskValues: [
      { name: 'Weather', value: parseFloat(weatherRisk.toFixed(1)), level: classifyLevel(weatherRisk) },
      { name: 'Terrain', value: parseFloat(terrainRisk.toFixed(1)), level: classifyLevel(terrainRisk) },
      { name: 'POI & Coverage', value: parseFloat(poiCoverageRisk.toFixed(1)), level: classifyLevel(poiCoverageRisk) },
      { name: 'Composite', value: parseFloat(compositeRisk.toFixed(1)), level: classifyLevel(compositeRisk) }
    ]
  };
};
