module.exports = {
  project: {
    ios: {},
  },
    assets: ['./assets/fonts'],
  };
